# NOVA computer controls

Double-click **NOVA + OmniRoute** on your desktop. Startup now starts the web app, gateway and local computer helper together. Open http://127.0.0.1:8000 and choose **Computer** beside the chat input, then **Enable computer tools**. Choose an available model that supports function/tool calling; a model being listed does not guarantee those capabilities or provider availability.

Examples:
- “List my Downloads, organize recognizable files by type, then verify what moved.”
- “Find installed apps named Paint and open Paint.”
- “Find my notes in S:\jarvis\projects, read the file, then make this edit.”
- “Inspect the open app window and type this text into its editor.”
- “Show the Recycle Bin count. Ask me before emptying it.”

Read targets and details in the Computer panel before selecting **Confirm action**. Cancelling or pressing **Stop** ends the current task; it will not replay when you enable controls again. Confirmations expire after two minutes and reject changed targets. Ctrl+Alt+Pause is the emergency stop for active tasks; moving the mouse to the top-left corner also stops automated pointer/keyboard input. A tab/model/conversation change stops its task. Use Windows normally if an elevated app, UAC, password box or lock screen requires manual input.

“Undo the last organization/file action” restores tracked moves or file edits when the affected items still match. Undo records and edit backups stay in the current user's protected runtime folder (S:\jarvis\data\computer), bound to the original conversation/task. New files and folders, copies, recycled items and permanent deletion do not currently have NOVA undo. Use Windows Recycle Bin to restore recycled items. Partial organization keeps an undo record. Cross-drive folder moves currently require copy, verification and separately confirmed recycling of the original.

Voice uses the same helper. Say “Hey Nova, open Paint” or “Hey Nova, organize my Downloads.” Protected actions are described first; say **confirm computer action** to approve that specific pending voice action or **cancel computer action**. “Yes” alone does not authorize deletion. Say **stop computer task** to stop the voice task. Voice listening remains a separate opt-in startup shortcut; NOVA's normal shortcut does not turn on the microphone.

Controls operate with your ordinary Windows account across local drives and folders that account can access. Remote NOVA pages and arbitrary websites cannot pair with the helper. No API keys are embedded in the frontend. Pairing credentials are encrypted using Windows DPAPI, and session tokens remain in memory. Requested file contents and accessibility observations go to your selected model. Screenshots are captured in memory; sharing them with an image-capable OmniRoute model requires the panel's explicit screenshot checkbox. Local history records action metadata, not file bodies, screenshots or pairing tokens.

If controls are offline, run the normal NOVA shortcut again. If a model fails or does not support tools/images, choose another available suitable model; the computer task does not silently switch providers. Program installations/removals and generic commands require confirmation. Commands run in a task-owned Windows job with bounded output/time; Stop terminates that job and its child processes. Sending messages, purchases and publishing require explicit instructions; keep the target app visible and review its final action.
