import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { FileCode2, RefreshCw, Save, Undo2, Terminal, History, Search, Play, Square, X, GitBranch, PanelRightClose, PanelRightOpen } from 'lucide-react';
import CodeMirror from '@uiw/react-codemirror';
import { useLocation } from 'react-router';
import { javascript } from '@codemirror/lang-javascript';
import { python } from '@codemirror/lang-python';
import { html } from '@codemirror/lang-html';
import { css } from '@codemirror/lang-css';
import { json } from '@codemirror/lang-json';
import { ChatArea } from '../components/Chat/ChatArea';
import { apiFetch, getBase } from '../lib/api';
import { useAppStore } from '../lib/store';
import { parseProjectCommand } from '../lib/project-command';
import './coding.css';

type Entry = { action: string; path?: string; diff?: string; output?: string; undone?: boolean; exit_code?: number };
type Job = { id: string; args: string[]; path: string; state: string; output: string; exit_code: number | null };
type Match = {path: string; line: number; text: string};
type Buffer = {text: string; saved: string};
type Tab = 'editor' | 'changes' | 'terminal' | 'preview' | 'search' | 'git';

export function CodingPage() {
  const location=useLocation();
  const streaming = useAppStore(s => s.streamState.isStreaming);
  const [workspace, setWorkspace] = useState('');
  const [mode,setMode]=useState<'plan'|'build'>('build');
  const [files, setFiles] = useState<string[]>([]);
  const [path, setPath] = useState('');
  const [buffers, setBuffers] = useState<Record<string, Buffer>>({});
  const [entries, setEntries] = useState<Entry[]>([]);
  const [command, setCommand] = useState('python -m unittest discover');
  const [folder, setFolder] = useState('.');
  const [jobs, setJobs] = useState<Job[]>([]);
  const [jobId, setJobId] = useState('');
  const [input, setInput] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState<Tab>('editor');
  const [previewPath, setPreviewPath] = useState('');
  const [query, setQuery] = useState('');
  const [matches, setMatches] = useState<Match[]>([]);
  const [gitOutput, setGitOutput] = useState('');
  const [gitCommand,setGitCommand]=useState('status --short');
  const [panel, setPanel] = useState(true);
  useEffect(() => {setPanel(true);},[location.key]);
  const buffersRef = useRef(buffers); buffersRef.current = buffers;
  const buffer = buffers[path];
  const operation = useCallback(async (body: Record<string, unknown>) => {
    const response = await apiFetch('/v1/coding/operation', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)});
    const result = await response.json();
    if (!response.ok) throw new Error(result.detail || 'Project operation failed');
    return result;
  }, []);
  const refresh = useCallback(async () => {
    const [listing, history] = await Promise.all([operation({action:'list'}), operation({action:'history'})]);
    setFiles(listing.files); setWorkspace(listing.workspace); setEntries(history.history);
    const settings=await apiFetch('/v1/coding/settings');if(settings.ok)setMode((await settings.json()).mode);
  }, [operation]);
  const act = useCallback(async (fn: () => Promise<void>) => {
    setBusy(true); setError('');
    try { await fn(); } catch(e) { setError(e instanceof Error ? e.message : 'Operation failed'); }
    finally { setBusy(false); }
  }, []);
  useEffect(() => { if (!streaming) void refresh().catch(e => setError(e.message)); }, [refresh, streaming]);
  useEffect(() => {
    if (streaming) return;
    let active = true;
    // Refresh clean buffers after assistant edits, preserving unsaved editor changes.
    for (const [name, value] of Object.entries(buffersRef.current)) {
      if (value.text !== value.saved) continue;
      void operation({action:'read',path:name}).then(file => {
        if (active) setBuffers(old => old[name]?.text === old[name]?.saved ? {...old,[name]:{text:file.content,saved:file.content}} : old);
      }).catch(() => {});
    }
    return () => {active=false;};
  }, [streaming, operation]);
  useEffect(() => {
    let active=true;
    const poll=async () => {
      try { const result=await operation({action:'jobs'}); if(active)setJobs(result.jobs); }
      catch(e) { if(active)setError(e instanceof Error ? e.message : 'Command sessions unavailable'); }
    };
    void poll(); const timer=window.setInterval(() => {void poll();},1000);
    return () => {active=false;window.clearInterval(timer);};
  }, [operation]);
  const open = (name:string) => void act(async () => {
    if (!buffersRef.current[name]) {
      const file=await operation({action:'read',path:name});
      setBuffers(old => ({...old,[name]:{text:file.content,saved:file.content}}));
    }
    setPath(name);setTab('editor');setPanel(true);
  });
  const save = useCallback(() => act(async () => {
    const value=buffersRef.current[path]; if (busy || !path || !value) return;
    await operation({action:'write',path,content:value.text,expected_content:value.saved});
    setBuffers(old => ({...old,[path]:{...old[path],saved:value.text}})); await refresh();
  }), [act, operation, path, refresh, busy]);
  useEffect(() => {
    const listener=(e:KeyboardEvent) => {if((e.ctrlKey || e.metaKey) && e.key==='s'){e.preventDefault();void save();}};
    window.addEventListener('keydown',listener);return () => window.removeEventListener('keydown',listener);
  },[save]);
  const extensions = useMemo(() => {
    const ext=path.split('.').pop();
    if(ext==='py')return [python()];
    if(['ts','tsx','js','jsx'].includes(ext || ''))return [javascript({jsx:true,typescript:ext==='ts' || ext==='tsx'})];
    if(ext==='html')return [html()]; if(ext==='css')return [css()]; if(ext==='json')return [json()];return [];
  },[path]);
  const selectedJob=jobs.find(j => j.id===jobId) || jobs[jobs.length-1];
  const create = () => {
    const name=window.prompt('New file path, relative to the workspace');
    if (!name?.trim())return;
    if(files.includes(name.trim())){open(name.trim());return;}
    setBuffers(old => ({...old,[name.trim()]:{text:'',saved:''}}));setPath(name.trim());setTab('editor');
  };
  const close = (name:string) => {
    if(buffers[name]?.text!==buffers[name]?.saved && !window.confirm('Discard unsaved changes to this file?'))return;
    setBuffers(old => {const next={...old};delete next[name];return next;});
    if(path===name)setPath(Object.keys(buffers).find(n => n!==name) || '');
  };
  const tabs: {id:Tab;label:string;icon:typeof FileCode2}[] = [
    {id:'editor',label:'Files',icon:FileCode2},{id:'search',label:'Search',icon:Search},{id:'changes',label:'Changes',icon:History},
    {id:'git',label:'Git',icon:GitBranch},{id:'preview',label:'Preview',icon:Play},{id:'terminal',label:'Commands',icon:Terminal},
  ];
  return <div className={`coding-page ${panel?'':'coding-page--chat'}`}>
    <section className="coding-assistant" aria-label="Coding assistant"><ChatArea/><button className="coding-panel-toggle" onClick={() => setPanel(!panel)} aria-label={panel?'Hide project panel':'Show project panel'}>{panel?<PanelRightClose size={15}/>:<PanelRightOpen size={15}/>}</button></section>
    {panel && <section className="coding-project" aria-label="Coding workspace">
      <header><FileCode2 size={16}/><div><strong>Project</strong><small title={workspace}>{workspace || 'Loading workspace…'}</small></div><select aria-label="Coding mode" value={mode} onChange={e => {const value=e.target.value as 'plan'|'build';void act(async () => {const response=await apiFetch('/v1/coding/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode:value})});if(!response.ok)throw new Error('Could not change coding mode');setMode(value);});}}><option value="build">Build</option><option value="plan">Plan · read only</option></select><button aria-label="Refresh project" disabled={busy} onClick={() => void act(refresh)}><RefreshCw size={14}/></button></header>
      <div className="coding-tabs">{tabs.map(({id,label,icon:Icon}) => <button key={id} className={tab===id?'active':''} onClick={() => {setTab(id);if(id==='preview')setPreviewPath(path.endsWith('.html')?path:files.find(f => f.endsWith('index.html')) || '');}}><Icon size={13}/>{label}</button>)}</div>
      {error && <p role="alert" className="coding-error">{error}</p>}
      {tab==='editor' && <>
        <div className="coding-editor-layout"><nav className="coding-files" aria-label="Project files"><div className="coding-explorer-title">EXPLORER <button onClick={create} aria-label="New file">+</button></div>{files.map(name => <button key={name} title={name} className={name===path?'active':''} disabled={busy} onClick={() => open(name)}><FileCode2 size={12}/>{name}</button>)}{!files.length && <p>Create a file or describe your project in chat.</p>}</nav>
        <div className="coding-document"><div className="coding-file-tabs">{Object.keys(buffers).map(name => <span key={name} className={name===path?'active':''}><button onClick={() => setPath(name)} title={name}>{name.split('/').pop()}{buffers[name].text!==buffers[name].saved?' •':''}</button><button aria-label={`Close ${name}`} onClick={() => close(name)}><X size={12}/></button></span>)}</div>
        {path && buffer ? <><div className="coding-breadcrumb">{path}</div><div className="coding-editor"><CodeMirror value={buffer.text} height="100%" theme="dark" extensions={extensions} basicSetup={{lineNumbers:true,foldGutter:true,highlightActiveLine:true,searchKeymap:true}} onChange={text => setBuffers(old => ({...old,[path]:{...old[path],text}}))}/></div></> : <div className="coding-empty"><FileCode2 size={28}/><p>Select a file to start editing.</p><small>Ctrl+S to save · Ctrl+F to find</small><button onClick={create}>New file</button></div>}</div></div>
        <footer><span>{path ? `${buffer?.text.split('\n').length || 0} lines · UTF-8`:'No file selected'}</span><button disabled={busy || !path} onClick={() => void save()}><Save size={13}/>Save</button><button disabled={busy || !path} onClick={() => void act(async () => {if(buffer?.text!==buffer?.saved && !window.confirm('Discard unsaved editor changes and reload this file?'))return;const file=await operation({action:'read',path});setBuffers(old => ({...old,[path]:{text:file.content,saved:file.content}}));})}>Reload</button><button disabled={busy} onClick={() => void act(async () => {if(buffer?.text!==buffer?.saved && !window.confirm('Discard unsaved editor changes before undoing?'))return;await operation({action:'undo'});await refresh();if(path){try{const file=await operation({action:'read',path});setBuffers(old => ({...old,[path]:{text:file.content,saved:file.content}}));}catch{close(path);}}})}><Undo2 size={13}/>Undo edit</button></footer>
      </>}
      {tab==='search' && <div className="coding-search"><form onSubmit={e => {e.preventDefault();void act(async () => {const result=await operation({action:'search',query});setMatches(result.matches);});}}><input aria-label="Search project" value={query} onChange={e => setQuery(e.target.value)} placeholder="Search all project files"/><button disabled={busy || !query}>Search</button></form>{matches.map((match,i) => <button className="coding-match" key={i} onClick={() => open(match.path)}><strong>{match.path}:{match.line}</strong><code>{match.text}</code></button>)}</div>}
      {tab==='changes' && <div className="coding-history">{[...entries].reverse().map((entry,i) => <article key={i}><strong>{entry.action==='edit'?`${entry.path}${entry.undone?' · undone':''}`:`Command · exit ${entry.exit_code}`}</strong><pre>{entry.diff || entry.output}</pre></article>)}{!entries.length && <p>No changes yet.</p>}</div>}
      {tab==='git' && <div className="coding-git"><label>Repository folder<input aria-label="Repository folder" value={folder} onChange={e => setFolder(e.target.value)}/></label><div className="coding-git-actions">{['status','diff','log','branch'].map(action => <button key={action} disabled={busy} onClick={() => void act(async () => {const result=await operation({action:'git',path:folder,args:action==='log'?['log','-10','--oneline']:action==='branch'?['branch','--list']:[action]});setGitOutput(result.output);})}>{action}</button>)}</div><form onSubmit={e => {e.preventDefault();void act(async () => {const result=await operation({action:'git',path:folder,args:parseProjectCommand(gitCommand)});setGitOutput(result.output);await refresh();});}}><input aria-label="Git arguments" value={gitCommand} onChange={e => setGitCommand(e.target.value)}/><button disabled={busy}>Run Git</button></form><small>init · switch -c branch · add filename · commit -m message · worktree add -b branch folder</small><pre>{gitOutput || 'Select a repository folder to inspect changes and branches.'}</pre></div>}
      {tab==='preview' && <div className="coding-preview">{previewPath ? <iframe title="Project preview" sandbox="allow-scripts" src={`${getBase()}/v1/coding/preview/${previewPath.split('/').map(encodeURIComponent).join('/')}`}/> : <p>Select an HTML file to preview it here.</p>}</div>}
      {tab==='terminal' && <div className="coding-terminal"><label>Working folder<input aria-label="Command working folder" value={folder} onChange={e => setFolder(e.target.value)}/></label><form onSubmit={e => {e.preventDefault();void act(async () => {const job=await operation({action:'job_start',args:parseProjectCommand(command),path:folder});setJobId(job.id);setJobs(old => [...old,job]);});}}><input aria-label="Project command" value={command} onChange={e => setCommand(e.target.value)}/><button disabled={busy || !command}><Play size={13}/>Run</button></form>
        <div className="coding-job-tabs">{jobs.map(job => <button key={job.id} className={selectedJob?.id===job.id?'active':''} onClick={() => setJobId(job.id)}>{job.args[0]} · {job.state}</button>)}</div>
        {selectedJob && <div className="coding-job-status"><span>{selectedJob.state}{selectedJob.exit_code!==null?` · exit ${selectedJob.exit_code}`:''}</span>{selectedJob.state==='running' && <button onClick={() => void act(async () => {await operation({action:'job_stop',id:selectedJob.id});})}><Square size={12}/>Stop</button>}</div>}
        <pre role="log" aria-label="Command output">{selectedJob?.output || 'Command output will appear here.'}</pre>
        {selectedJob?.state==='running' && <form onSubmit={e => {e.preventDefault();void act(async () => {await operation({action:'job_input',id:selectedJob.id,text:input});setInput('');});}}><input aria-label="Command input" value={input} onChange={e => setInput(e.target.value)} placeholder="Send input to the running command"/><button disabled={busy}>Send</button></form>}
        <small>Live process sessions · four concurrent commands · 30-minute limit</small>
      </div>}
    </section>}
  </div>;
}
