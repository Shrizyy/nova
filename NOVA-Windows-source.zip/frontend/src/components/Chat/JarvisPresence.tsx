import { useEffect, useState } from 'react';
import { getBase } from '../../lib/api';
import { useTtsStore } from '../../lib/tts';

type VoiceState = 'offline' | 'standby' | 'listening' | 'thinking' | 'speaking' | 'confirming';

export function JarvisPresence() {
  const [voiceState, setVoiceState] = useState<VoiceState>('offline');
  const browserSpeech = useTtsStore((state) => state.state);

  useEffect(() => {
    let active = true;
    const poll = async () => {
      try {
        const response = await fetch(`${getBase()}/v1/assistant/voice-state`, { cache: 'no-store' });
        if (!response.ok) throw new Error('Voice listener unavailable');
        const data = await response.json() as { state?: VoiceState };
        if (active) setVoiceState(data.state || 'offline');
      } catch {
        if (active) setVoiceState('offline');
      }
    };
    void poll();
    const timer = window.setInterval(() => { void poll(); }, 800);
    return () => { active = false; window.clearInterval(timer); };
  }, []);

  const speaking = voiceState === 'speaking' || browserSpeech === 'speaking';
  const busy = voiceState === 'thinking' || browserSpeech === 'loading';
  const label = speaking ? 'SPEAKING' : busy ? 'PROCESSING' : voiceState === 'listening' ? 'LISTENING' : voiceState === 'offline' ? 'VOICE OFFLINE' : 'SAY HEY NOVA';

  return (
    <>
      <div className="jarvis-voice-pill" role="status" aria-live="polite">
        <span className={`jarvis-voice-pill__dot ${speaking || voiceState === 'listening' ? 'is-active' : ''}`} />
        <span>{label}</span>
        <span className="jarvis-voice-pill__bars" aria-hidden="true"><i /><i /><i /><i /><i /></span>
      </div>
      {speaking && (
        <div className="jarvis-speaking-panel" role="status" aria-label="Nova is speaking">
          <div className="jarvis-speaking-panel__top"><span>J.A.R.V.I.S</span><span>VOICE OUTPUT // LIVE</span></div>
          
          <div className="jarvis-speaking-panel__bottom">
            <span className="jarvis-speaking-panel__live" />
            SPEAKING
            <span className="jarvis-speaking-panel__wave" aria-hidden="true"><i /><i /><i /><i /><i /><i /><i /></span>
          </div>
        </div>
      )}
    </>
  );
}
