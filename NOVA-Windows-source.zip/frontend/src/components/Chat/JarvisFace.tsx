import { useId } from 'react';

type JarvisFaceProps = { speaking?: boolean; compact?: boolean };

/** Projected wireframe portrait; speech animates the lips and projection glow. */
export function JarvisFace({ speaking = false, compact = false }: JarvisFaceProps) {
  const id = useId();
  const glow = `${id}-glow`;
  const fade = `${id}-fade`;
  const clip = `${id}-clip`;
  const head = 'M160 32 C101 32 75 75 80 136 C83 171 91 210 111 237 C127 261 145 275 160 278 C175 275 193 261 209 237 C229 210 237 171 240 136 C245 75 219 32 160 32Z';
  return (
    <div className={`jarvis-face jarvis-hologram ${speaking ? 'jarvis-face--speaking' : ''} ${compact ? 'jarvis-face--compact' : ''}`}
      role="img" aria-label={speaking ? 'Hologram face speaking' : 'NOVA hologram face'}>
      <div className="jarvis-face__halo jarvis-face__halo--outer" />
      <div className="jarvis-face__halo jarvis-face__halo--inner" />
      <svg className="jarvis-face__portrait" viewBox="0 0 320 340" fill="none" aria-hidden="true">
        <defs>
          <linearGradient id={fade} x1="160" y1="28" x2="160" y2="330" gradientUnits="userSpaceOnUse">
            <stop stopColor="#99F8FF" stopOpacity=".8" /><stop offset=".55" stopColor="#43D5F3" stopOpacity=".55" /><stop offset="1" stopColor="#7786FF" stopOpacity="0" />
          </linearGradient>
          <filter id={glow}><feGaussianBlur stdDeviation="2.4" /></filter>
          <clipPath id={clip}><path d={head} /></clipPath>
        </defs>
        <path d={head} fill="#1FA9D4" fillOpacity=".055" stroke={`url(#${fade})`} strokeWidth="1.5" />
        <g clipPath={`url(#${clip})`} stroke={`url(#${fade})`} strokeWidth=".8" opacity=".7">
          {Array.from({ length: 18 }, (_, i) => {
            const y = 40 + i * 14;
            return <path key={`h${i}`} d={`M68 ${y} Q160 ${y + 28} 252 ${y}`} />;
          })}
          {Array.from({ length: 15 }, (_, i) => {
            const x = 62 + i * 14;
            return <path key={`v${i}`} d={`M${x} 20 Q${160 + (x - 160) * .42} 159 ${160 + (x - 160) * .8} 285`} />;
          })}
        </g>
        <g stroke="#95EEFF" strokeLinecap="round">
          <path d="M100 139 Q119 124 139 140 M181 140 Q201 124 220 139" strokeOpacity=".65" />
          <path d="M102 148 Q119 163 138 149 M182 149 Q201 163 218 148" strokeWidth="1.6" />
          <path d="M112 149 Q120 143 130 149 M190 149 Q200 143 208 149" strokeWidth="3" filter={`url(#${glow})`} />
          <path d="M157 151 Q151 176 148 191 Q160 199 172 191 M160 153 L163 185" strokeOpacity=".6" />
          <path className="jarvis-face__mouth" d="M136 225 Q148 218 160 222 Q172 218 184 225 Q160 237 136 225Z" strokeWidth="1.3" fill="#6AEAFF" fillOpacity=".15" />
          <path d="M149 250 Q160 254 171 250" strokeOpacity=".4" />
          <path d="M118 255 L112 287 Q82 296 64 321 M202 255 L208 287 Q238 296 256 321" stroke={`url(#${fade})`} />
          <path d="M112 287 Q160 317 208 287 M84 305 Q160 340 236 305" stroke={`url(#${fade})`} />
        </g>
        <g fill="#9EF9FF" opacity=".8">
          {[[96,104],[121,83],[160,68],[197,83],[224,104],[92,177],[119,194],[201,194],[228,177],[139,251],[181,251]].map(([x,y]) => <circle key={`${x}-${y}`} cx={x} cy={y} r="1.4" />)}
        </g>
        <ellipse cx="160" cy="323" rx="83" ry="8" stroke="#55DDF9" strokeOpacity=".3" />
        <ellipse cx="160" cy="323" rx="58" ry="3" fill="#55DDF9" fillOpacity=".15" filter={`url(#${glow})`} />
      </svg>
      <div className="jarvis-face__scan" />
    </div>
  );
}
