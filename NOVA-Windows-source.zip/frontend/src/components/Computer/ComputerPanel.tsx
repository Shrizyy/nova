import {useComputerStore} from '../../lib/computer-store';
import {isLocalComputer} from '../../lib/computer-client';

export function ComputerPanel(){
  const state=useComputerStore();
  if(!state.panelOpen)return null;
  const approval=state.pending?.result.data.approval;
  return <aside aria-label="Computer controls" style={{position:'fixed',right:16,top:76,width:340,maxWidth:'calc(100vw - 32px)',maxHeight:'calc(100vh - 100px)',overflowY:'auto',zIndex:100,background:'var(--color-bg-secondary,#141820)',border:'1px solid var(--color-border,#30343b)',borderRadius:16,padding:20,color:'var(--color-text-primary,#f1f1f1)',boxShadow:'0 12px 40px #0005'}}>
    <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16}}><strong>Computer</strong><button type="button" onClick={()=>{void state.disable();state.open(false);}} aria-label="Close computer panel">×</button></div>
    <p style={{fontSize:13,lineHeight:1.6,marginBottom:16}}>Work with files, apps, screen and commands on this laptop. Requested file contents and screen observations may be shared with your selected model. Screenshots are not saved by default.</p>
    <div style={{display:'flex',gap:12,marginBottom:16}}>
      <button type="button" disabled={!isLocalComputer()} onClick={()=>state.enabled?void state.disable():state.enable()} style={{padding:'8px 12px',border:'1px solid #555',borderRadius:8}}>{state.enabled?'Disable computer tools':'Enable computer tools'}</button>
      <button type="button" onClick={()=>void state.stop()} disabled={!state.busy&&!state.pending} style={{padding:'8px 12px',border:'1px solid #995a56',borderRadius:8}}>Stop</button>
    </div>
    {!isLocalComputer()&&<p>Available only at localhost on this laptop.</p>}
    <label style={{display:'flex',gap:8,fontSize:12,marginBottom:12}}><input type="checkbox" checked={state.allowImages} onChange={e=>useComputerStore.setState({allowImages:e.target.checked})}/>Send requested screenshots to the model (requires image support)</label>
    <p role="status" style={{fontSize:13,marginBottom:8}}>{state.phase}</p>
    <p style={{fontSize:11,color:'#a4a8b0',marginBottom:16}}>Emergency stop: Ctrl + Alt + Pause</p>
    {state.error&&<p role="alert" style={{color:'#eea5a0',fontSize:12,marginBottom:12}}>{state.error}</p>}
    {approval&&<section style={{border:'1px solid #716249',padding:14,borderRadius:10,marginBottom:16}}>
      <strong>Confirm this action</strong>
      <p style={{fontSize:13,margin:'10px 0'}}>{String(approval.operation).replace(/_/g,' ')} {approval.params.path||approval.params.package_id||''}</p>
      {approval.preview?.permanent&&<p style={{fontSize:12,color:'#efb6a4'}}>This permanently deletes items. It cannot be undone through NOVA.</p>}
      <details><summary style={{fontSize:12,cursor:'pointer'}}>Targets and details</summary><pre style={{fontSize:11,whiteSpace:'pre-wrap',maxHeight:220,overflow:'auto'}}>{JSON.stringify({params:approval.params,preview:approval.preview},null,2)}</pre></details>
      <div style={{display:'flex',gap:12,marginTop:12}}><button type="button" disabled={state.approving} onClick={()=>void state.confirm()} style={{padding:8,border:'1px solid #888',borderRadius:8}}>Confirm action</button><button type="button" onClick={()=>void state.deny()} style={{padding:8}}>Cancel</button></div>
    </section>}
    <div style={{fontSize:12}}><strong>Recent actions</strong>{state.recent.slice(-6).reverse().map((r,i)=><p key={`${r.action_id}-${i}`} style={{marginTop:8,color:'#bfc2c8'}}>{r.summary}</p>)}</div>
  </aside>;
}
