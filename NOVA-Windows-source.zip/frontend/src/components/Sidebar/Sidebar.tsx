import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router';
import { MessageSquare, Plus, BarChart3, Settings, Search, PanelLeftClose, PanelLeft, Cpu, Cloud, Rocket, Bot, Moon, Sun, Monitor, ScrollText, Database, ChevronDown, Network } from 'lucide-react';
import { ConversationList } from './ConversationList';
import { useAppStore } from '../../lib/store';
import { fetchModels, getLocalCloudStatus } from '../../lib/api';
import './sidebar.css';

export function Sidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const [geminiModel, setGeminiModel] = useState('');
  const [switchError, setSwitchError] = useState('');
  const [switching, setSwitching] = useState(false);
  const sidebarOpen = useAppStore(s => s.sidebarOpen);
  const toggleSidebar = useAppStore(s => s.toggleSidebar);
  const selectedModel = useAppStore(s => s.selectedModel);
  const serverInfo = useAppStore(s => s.serverInfo);
  const models = useAppStore(s => s.models);
  const modelLoading = useAppStore(s => s.modelLoading);
  const isStreaming = useAppStore(s => s.streamState.isStreaming);
  const settings = useAppStore(s => s.settings);
  const currentModel = selectedModel || serverInfo?.model || '';
  const provider = currentModel.startsWith('omniroute/') ? 'OmniRoute' : currentModel.startsWith('gemini-') ? 'Gemini' : 'Local';
  const ThemeIcon = settings.theme === 'light' ? Sun : settings.theme === 'dark' ? Moon : Monitor;
  useEffect(() => {
    let active = true;
    const refresh = () => getLocalCloudStatus().then(status => { if (active) setGeminiModel(status.gemini_model || ''); }).catch(() => {});
    void refresh();
    const timer = window.setInterval(refresh, 30000);
    return () => { active = false; window.clearInterval(timer); };
  }, []);
  const chooseProvider = async (target: 'Local' | 'Gemini' | 'OmniRoute') => {
    if (switching || modelLoading || isStreaming) return;
    setSwitching(true); setSwitchError('');
    try {
      let chosen = '';
      if (target === 'Gemini') {
        const status = await getLocalCloudStatus();
        chosen = status.gemini_model;
        setGeminiModel(chosen);
        if (!chosen) throw new Error('Gemini is not connected. Check your saved API key.');
      } else {
        const available = await fetchModels();
        useAppStore.getState().setModels(available);
        if (target === 'OmniRoute') {
          const candidates = available.filter(m => m.id.startsWith('omniroute/'));
          chosen = candidates.find(m => m.id === 'omniroute/codex/gpt-5.6-luna-low')?.id || candidates[0]?.id || '';
          if (!chosen) throw new Error('OmniRoute is offline. Restart NOVA to start the gateway.');
        } else {
          const candidates = available.filter(m => m.owned_by !== 'litellm' && !m.id.startsWith('omniroute/') && !m.id.startsWith('gemini-'));
          chosen = candidates.find(m => m.id === 'qwen3.5:4b')?.id || candidates[0]?.id || '';
          if (!chosen) throw new Error('No local model is available. Check Ollama.');
        }
      }
      useAppStore.getState().setSelectedModel(chosen);
    } catch (error) { setSwitchError(error instanceof Error ? error.message : 'Could not select provider.'); }
    finally { setSwitching(false); }
  };
  const newChat = () => {
    const state = useAppStore.getState();
    if (state.messages.length) state.createConversation(currentModel);
    navigate('/');
  };
  const nav = [
    { path: '/', icon: MessageSquare, label: 'Chat' },
    { path: '/coding', icon: Cpu, label: 'Coding' },
    { path: '/dashboard', icon: BarChart3, label: 'Dashboard' },
    { path: '/data-sources', icon: Database, label: 'Data Sources' },
    { path: '/agents', icon: Bot, label: 'Agents' },
    { path: '/logs', icon: ScrollText, label: 'Logs' },
    { path: '/settings', icon: Settings, label: 'Settings' },
    { path: '/get-started', icon: Rocket, label: 'Get Started' },
  ];
  const disabled = switching || modelLoading || isStreaming;
  return <>
    {!sidebarOpen && <button aria-label="Open sidebar" onClick={toggleSidebar} className="jarvis-sidebar-toggle"><PanelLeft size={18} /></button>}
    <aside className={`jarvis-sidebar ${sidebarOpen ? 'is-open' : ''}`} aria-label="Main navigation">
      <div className="jarvis-sidebar__inner">
        <header className="jarvis-sidebar__header">
          <div className="jarvis-sidebar__brand"><img src="/jarvis-mark.svg" alt="" /><div title="Neural Operations & Versatile Assistant">NOVA<span>YOUR WORKSPACE</span></div></div>
          <button aria-label="Close sidebar" onClick={toggleSidebar} className="jarvis-sidebar__icon"><PanelLeftClose size={17} /></button>
        </header>
        <button onClick={newChat} className="jarvis-sidebar__new"><Plus size={17} /> New conversation<span>+</span></button>
        <section className="jarvis-sidebar__provider" aria-label="AI provider">
          <div className="jarvis-sidebar__label">CONNECTIONS<span className="jarvis-sidebar__count">{models.filter(m => m.id.startsWith('omniroute/')).length} routes</span></div>
          <div className="jarvis-sidebar__providers">
            {([{name:'Local', icon:Cpu},{name:'Gemini',icon:Cloud},{name:'OmniRoute',icon:Network}] as const).map(item => <button key={item.name} onClick={() => void chooseProvider(item.name)} disabled={disabled} aria-pressed={provider === item.name} title={item.name === 'Gemini' && !geminiModel ? 'Check Gemini connection' : `Use ${item.name}`}><item.icon size={14}/>{item.name}</button>)}
          </div>
          <button className="jarvis-sidebar__model" onClick={() => useAppStore.getState().setCommandPaletteOpen(true)} aria-label="Choose a model"><div><span>{modelLoading ? 'Loading model…' : 'CURRENT MODEL'}</span><strong>{currentModel.replace(/^omniroute\//, '') || 'Choose a model'}</strong></div><ChevronDown size={15}/></button>
          {switchError && <p role="alert" className="jarvis-sidebar__error">{switchError}</p>}
        </section>
        <nav className="jarvis-sidebar__nav">{nav.map(item => <button key={item.path} aria-current={location.pathname === item.path ? 'page' : undefined} onClick={() => { navigate(item.path); if (window.innerWidth < 768) useAppStore.getState().setSidebarOpen(false); }}><item.icon size={17}/>{item.label}</button>)}</nav>
        <div className="jarvis-sidebar__label jarvis-sidebar__recent">RECENT CONVERSATIONS</div>
        <label className="jarvis-sidebar__search"><Search size={14}/><input aria-label="Search chats" placeholder="Search conversations" value={searchQuery} onChange={event => setSearchQuery(event.target.value)}/></label>
        <div className="jarvis-sidebar__chats"><ConversationList searchQuery={searchQuery}/></div>
        <footer className="jarvis-sidebar__footer"><span><i/> Personal workspace</span><button className="jarvis-sidebar__icon" title={`Theme: ${settings.theme}`} aria-label="Change theme" onClick={() => useAppStore.getState().updateSettings({theme:settings.theme === 'light' ? 'dark' : settings.theme === 'dark' ? 'system' : 'light'})}><ThemeIcon size={16}/></button></footer>
      </div>
    </aside>
  </>;
}
