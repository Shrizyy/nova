import type { CSSProperties, ReactNode } from 'react';
import ResponsiveHeroBanner, { HERO_BACKGROUND } from './responsive-hero-banner';
import {
  Code2, Rocket, Layers, FileUp,
} from 'lucide-react';
import { Button } from '@/components/ui/button';

type MoonChatProps = {
  empty: boolean;
  header: ReactNode;
  composer: ReactNode;
  children: ReactNode;
  onPrompt: (prompt: string) => void;
  onNavigate: (path: string) => void;
};

/** The supplied moon layout, connected to JARVIS's existing chat composer. */
export default function RuixenMoonChat({
  empty, header, composer, children, onPrompt, onNavigate,
}: MoonChatProps) {
  const actions = [
    { icon: Code2, label: 'Open project', run: () => onNavigate('/coding') },
    { icon: Layers, label: 'Review changes', run: () => onPrompt('Inspect my project changes and review them for bugs. ') },
    { icon: Rocket, label: 'Run tests', run: () => onPrompt('Find and run the tests for my project, then report the actual results. ') },
    { icon: FileUp, label: 'Documents', run: () => onNavigate('/data-sources') },
  ];

  return (
    <section className={`moon-chat ${empty ? 'moon-chat--empty nova-hero-mode' : ''}`} aria-label="NOVA chat" style={{ '--nova-hero-image': `url("${HERO_BACKGROUND}")` } as CSSProperties}>
      <div className="moon-chat__background" aria-hidden="true" />
      <div className="moon-chat__header">{header}</div>
      <div className="moon-chat__viewport">
        {empty ? (
          <ResponsiveHeroBanner
            onChat={() => document.querySelector<HTMLTextAreaElement>('.mo-field')?.focus()}
            onCoding={() => onNavigate('/coding')}
            onRea={() => {
              onPrompt('Use REA to analyze an app without running it. Ask me for its absolute file path and what I want to understand. ');
              requestAnimationFrame(() => document.querySelector<HTMLTextAreaElement>('.mo-field')?.focus());
            }}
          />
        ) : children}
      </div>
      <div className="moon-chat__bottom">
        {composer}
        {empty && (
          <nav className="moon-chat__actions" aria-label="Quick actions">
            {actions.map(({ icon: Icon, label, run }) => (
              <Button key={label} type="button" variant="outline" className="moon-chat__action" onClick={run}>
                <Icon size={15} aria-hidden="true" />
                <span>{label}</span>
              </Button>
            ))}
          </nav>
        )}
      </div>
    </section>
  );
}
