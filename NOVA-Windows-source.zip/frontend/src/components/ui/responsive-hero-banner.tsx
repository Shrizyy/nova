import { useState } from 'react';
import { ArrowRight, ArrowUpRight, Code2, Menu, ScanSearch, X } from 'lucide-react';
import './responsive-hero-banner.css';

export const HERO_BACKGROUND = '/assets/nova-hero-background.jpg';

interface ResponsiveHeroBannerProps {
  onChat: () => void;
  onCoding: () => void;
  onRea: () => void;
}

/** Supplied responsive hero, adapted for the local NOVA workspace. */
export default function ResponsiveHeroBanner({ onChat, onCoding, onRea }: ResponsiveHeroBannerProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const actions = [
    { label: 'Chat', run: onChat },
    { label: 'Coding', run: onCoding },
    { label: 'REA', run: onRea },
  ];
  const run = (action: () => void) => { setMobileMenuOpen(false); action(); };
  return (
    <section className="nova-hero" aria-label="Welcome to NOVA">
      <header className="nova-hero__nav">
        <span className="nova-hero__wordmark">NOVA <small>Neural Operations &amp; Versatile Assistant</small></span>
        <nav className="nova-hero__desktop-nav" aria-label="Workspace navigation">
          {actions.map(({label, run: action}) => <button type="button" key={label} onClick={() => run(action)}>{label}</button>)}
          <button type="button" className="nova-hero__nav-cta" onClick={onCoding}>Open workspace <ArrowUpRight size={14} aria-hidden="true" /></button>
        </nav>
        <button type="button" className="nova-hero__menu-toggle" aria-label={mobileMenuOpen ? 'Close welcome menu' : 'Open welcome menu'} aria-expanded={mobileMenuOpen} aria-controls="nova-welcome-menu" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
          {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
        {mobileMenuOpen && <nav id="nova-welcome-menu" className="nova-hero__mobile-nav" aria-label="Mobile workspace navigation">
          {actions.map(({label, run: action}) => <button type="button" key={label} onClick={() => run(action)}>{label}</button>)}
        </nav>}
      </header>
      <div className="nova-hero__copy">
        <span className="nova-hero__badge"><span>Your workspace</span> From an idea to something real</span>
        <h1>A place for your<br /> next great idea.</h1>
        <p>Think it through. Build it out. Understand how it works.<br className="nova-hero__desktop-break" /> Your conversations, code and app analysis, together.</p>
        <div className="nova-hero__actions">
          <button type="button" onClick={onCoding}><Code2 size={16} aria-hidden="true" /> Start building <ArrowRight size={16} aria-hidden="true" /></button>
          <button type="button" onClick={onRea}><ScanSearch size={16} aria-hidden="true" /> Analyze an app</button>
        </div>
      </div>
    </section>
  );
}
