import { useEffect, useState, useRef } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router';
import { ApprovalBell } from './ApprovalBell';
import { Sidebar } from './Sidebar/Sidebar';
import { SystemPulse } from './SystemPulse';
import { JarvisPresence } from './Chat/JarvisPresence';
import { useAppStore } from '../lib/store';
import { checkHealth } from '../lib/api';
import {ComputerPanel} from './Computer/ComputerPanel';
import {useComputerStore} from '../lib/computer-store';
import {shouldStopComputerTransition} from '../lib/computer-ownership';

export function Layout() {
  const sidebarOpen = useAppStore((s) => s.sidebarOpen);
  const activeId = useAppStore(s=>s.activeId);
  const selectedModel = useAppStore(s=>s.selectedModel);
  const location = useLocation();
  const previousView=useRef({conversationId:activeId,model:selectedModel,path:location.pathname});
  useEffect(()=>{
    const next={conversationId:activeId,model:selectedModel,path:location.pathname};
    if(shouldStopComputerTransition(previousView.current,next,useComputerStore.getState()))void useComputerStore.getState().stop();
    previousView.current=next;
  },[activeId,selectedModel,location.pathname]);
  useEffect(()=>{
    const stopOnExit=()=>{if(useComputerStore.getState().session||useComputerStore.getState().busy)void useComputerStore.getState().stop();};
    window.addEventListener('pagehide',stopOnExit);
    return ()=>window.removeEventListener('pagehide',stopOnExit);
  },[]);
  const [apiReachable, setApiReachable] = useState<boolean | null>(null);

  useEffect(() => {
    const check = () => checkHealth().then(setApiReachable);
    check();
    const interval = setInterval(check, 30000);
    const onFocus = () => check();
    window.addEventListener('focus', onFocus);
    return () => {
      clearInterval(interval);
      window.removeEventListener('focus', onFocus);
    };
  }, []);

  const navigate = useNavigate();

  return (
    <div className={`flex flex-col h-full w-full overflow-hidden relative ${sidebarOpen ? "jarvis-sidebar-expanded" : ""}`} style={{ paddingTop: '3px' }}>
      <div className="hud-backdrop" aria-hidden="true" />
      <SystemPulse apiReachable={apiReachable} />
      <JarvisPresence />
      <ApprovalBell />
      <ComputerPanel />

      {/* Health check banner */}
      {apiReachable === false && (
        <div
          className="flex items-center gap-3 px-4 py-2 text-sm shrink-0"
          style={{
            background: 'color-mix(in srgb, var(--color-error) 8%, transparent)',
            borderBottom: '1px solid color-mix(in srgb, var(--color-error) 15%, transparent)',
            color: 'var(--color-text)',
          }}
        >
          <span
            className="w-1.5 h-1.5 rounded-full shrink-0"
            style={{ background: 'var(--color-error)' }}
          />
          <span>Cannot reach NOVA backend</span>
          <button
            onClick={() => navigate('/settings')}
            className="text-sm underline cursor-pointer ml-auto shrink-0"
            style={{ color: 'var(--color-accent)' }}
          >
            Change URL
          </button>
        </div>
      )}

      <div className="flex flex-1 min-h-0 relative z-10">
        <Sidebar />
        {sidebarOpen && (
          <div
            className="fixed inset-0 z-20 bg-black/40 md:hidden"
            onClick={() => useAppStore.getState().setSidebarOpen(false)}
          />
        )}
        <main className="flex-1 flex flex-col min-w-0 h-full relative overflow-hidden" style={{ background: 'transparent' }}>
          <div className="flex-1 flex flex-col min-w-0 min-h-0 relative z-[2]">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
