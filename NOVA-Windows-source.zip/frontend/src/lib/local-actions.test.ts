import { afterEach, describe, expect, it, vi } from 'vitest';
import { localActionCommand } from './local-actions';

afterEach(() => vi.unstubAllGlobals());

describe('local laptop action routing', () => {
  it('routes a typed wake phrase instead of sending it to a model', () => {
    vi.stubGlobal('window', { location: { hostname: '127.0.0.1' } });
    expect(localActionCommand('Hey Jarvis, organize my Downloads', []))
      .toBe('organize my Downloads');
  });

  it('uses the recent organization request when told to do it', () => {
    vi.stubGlobal('window', { location: { hostname: '127.0.0.1' } });
    expect(localActionCommand('you do it', ['Can you help me organize my Downloads?']))
      .toBe('organize my Downloads');
  });

  it('keeps public tunnel visitors away from laptop actions', () => {
    vi.stubGlobal('window', { location: { hostname: 'example.ngrok-free.dev' } });
    expect(localActionCommand('Hey Jarvis, organize my Downloads', [])).toBeNull();
  });
});
