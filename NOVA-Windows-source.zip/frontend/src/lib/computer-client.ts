import { authHeaders } from './api';

export type ComputerSession = {session_id:string;task_id:string;token:string;channel:'chat'|'voice'};
export type ComputerRequest = {operation:string;params?:Record<string,unknown>};
export type ComputerResult = {action_id:string;status:'success'|'partial'|'awaiting_confirmation'|'cancelled'|'unsupported'|'failed';summary:string;data:Record<string,any>};

export function isLocalComputer(): boolean {
  return ['127.0.0.1','localhost'].includes(window.location.hostname) && window.location.port === '8000';
}

export async function pairComputer(taskId:string):Promise<ComputerSession> {
  if (!isLocalComputer()) throw new Error('Computer controls are available only in the local NOVA window.');
  const response = await fetch(`${window.location.origin}/v1/computer/pairing`, {
    method:'POST',headers:authHeaders({'Content-Type':'application/json'}),body:JSON.stringify({task_id:taskId}),signal:AbortSignal.timeout(10000),
  });
  if (!response.ok) throw new Error('Computer controls are offline. Use the NOVA shortcut to start them.');
  return response.json();
}

export async function computerCall(session:ComputerSession, endpoint:string, payload:Record<string,unknown>={}, signal?:AbortSignal):Promise<any> {
  if (!isLocalComputer()) throw new Error('Computer controls require the local NOVA window.');
  const response = await fetch(`http://127.0.0.1:8766${endpoint}`, {
    method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${session.token}`},
    body:JSON.stringify({task_id:session.task_id,...payload}),signal,keepalive:endpoint==='/cancel',
  });
  if (!response.ok) throw new Error(response.status===403 ? 'Computer session expired. Enable controls again; the previous action was not replayed.' : `Computer action failed (${response.status}).`);
  return response.json();
}

export function executeComputerAction(session:ComputerSession, request:ComputerRequest, signal?:AbortSignal):Promise<ComputerResult> {
  return computerCall(session,'/operation',{...request,params:request.params||{}},signal);
}
export function approveComputerAction(session:ComputerSession, approvalId:string):Promise<ComputerResult> {
  return computerCall(session,'/approve',{approval_id:approvalId});
}
export function stopComputerTask(session:ComputerSession):Promise<void> {
  return computerCall(session,'/cancel').then(()=>undefined);
}
