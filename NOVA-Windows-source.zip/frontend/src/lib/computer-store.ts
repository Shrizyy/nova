import {create} from 'zustand';
import {authHeaders} from './api';
import {pairComputer,computerCall,executeComputerAction,approveComputerAction,stopComputerTask,type ComputerSession,type ComputerRequest,type ComputerResult} from './computer-client';
import {runComputerLoop,COMPUTER_TOOLS,type ComputerMessage} from './computer-loop';

type Pending = {result:ComputerResult;resolve:(result:ComputerResult)=>void};
type State = {
  taskId:string|null;enabled:boolean;panelOpen:boolean;busy:boolean;approving:boolean;phase:string;error:string;session:ComputerSession|null;pending:Pending|null;
  recent:ComputerResult[];allowImages:boolean;
  open:(value:boolean)=>void;enable:()=>void;disable:()=>Promise<void>;stop:()=>Promise<void>;
  ensureSession:(taskId:string)=>Promise<ComputerSession>;
  request:(request:ComputerRequest,taskId:string,signal?:AbortSignal)=>Promise<ComputerResult>;
  legacy:(command:string,taskId:string,signal?:AbortSignal)=>Promise<ComputerResult>;
  confirm:()=>Promise<void>;deny:()=>Promise<void>;
  run:(messages:ComputerMessage[],model:string,taskId:string,signal:AbortSignal)=>Promise<string>;
};
let controller:AbortController|null = null;
let ownershipEpoch=0;
export const useComputerStore = create<State>((set,get)=>({
  taskId:null,enabled:false,panelOpen:false,busy:false,approving:false,phase:'Ready when needed',error:'',session:null,pending:null,recent:[],allowImages:false,
  open:panelOpen=>set({panelOpen}),
  enable:()=>set({enabled:true,panelOpen:true,error:''}),
  disable:async()=>{await get().stop();set({enabled:false});},
  stop:async()=>{
    ownershipEpoch++;
    controller?.abort();
    const {session,pending}=get();
    pending?.resolve({status:'cancelled',summary:'Computer task stopped.',data:{},action_id:'cancelled'});
    set({pending:null,busy:false,phase:'Stopped',session:null,taskId:null});
    if (session) {try {await stopComputerTask(session);} catch {set({error:'Stop could not reach the helper. Press Ctrl+Alt+Pause to stop desktop input.'});}}
  },
  ensureSession:async(taskId)=>{
    const current=get().session;
    if(current?.task_id===taskId) return current;
    if(current) await get().stop();
    const epoch=++ownershipEpoch;
    set({busy:true,taskId,phase:'Connecting computer controls'});
    try {
      const session=await pairComputer(taskId);
      if(epoch!==ownershipEpoch){await stopComputerTask(session);throw new DOMException('Computer task stopped.','AbortError');}
      set({session,error:''});return session;
    } finally {if(epoch===ownershipEpoch)set({busy:false});}
  },
  request:async(request,taskId,signal)=>{
    const session=await get().ensureSession(taskId);
    const result=await executeComputerAction(session,request,signal);
    return acceptResult(result,signal);
  },
  legacy:async(command,taskId,signal)=>{
    const session=await get().ensureSession(taskId);
    try {
      set({busy:true,phase:'Working on your laptop',error:''});
      return await acceptResult(await computerCall(session,'/legacy',{command},signal),signal);
    } finally {set({busy:false});}
  },
  confirm:async()=>{
    const {session,pending,approving}=get();if(!session||!pending||approving)return;
    set({approving:true});
    try{
      const result=await approveComputerAction(session,pending.result.data.approval.id);
      if(get().pending!==pending)return;
      set({pending:null,phase:result.summary,recent:[...get().recent.slice(-19),result]});pending.resolve(result);
    }catch(error){set({error:String(error)});await get().stop();}
    finally{set({approving:false});}
  },
  deny:async()=>{
    const {session,pending}=get();if(!session||!pending)return;
    try{await computerCall(session,'/deny',{approval_id:pending.result.data.approval.id});}catch{}
    set({pending:null});pending.resolve({status:'cancelled',summary:'Cancelled the requested action.',data:{},action_id:'denied'});
  },
  run:async(messages,model,taskId,signal)=>{
    const ownSession=await get().ensureSession(taskId);
    signal.throwIfAborted();
    const ownController=new AbortController();controller=ownController;
    const abort=()=>{void get().stop();};signal.addEventListener('abort',abort,{once:true});
    const ownSignal=ownController.signal;
    set({busy:true,error:'',phase:'Planning the requested laptop task'});
    try{
      return await runComputerLoop({messages,signal:ownSignal,allowImages:get().allowImages,
        onEvent:phase=>set({phase}),execute:req=>get().request(req,taskId,ownSignal),
        complete:async(history)=>{
          const response=await fetch(`${window.location.origin}/v1/computer/model`,{method:'POST',headers:authHeaders({'Content-Type':'application/json'}),body:JSON.stringify({model,messages:history,tools:COMPUTER_TOOLS,stream:false,max_tokens:2048}),signal:ownSignal});
          if(!response.ok){const text=await response.text();throw new Error(`Selected model could not run the computer task (${response.status}). ${text.slice(0,250)} Choose a tool-capable model; NOVA did not switch models.`);}
          const result=await response.json();return result.choices[0].message;
        },
      });
    }catch(error){if(!(error instanceof DOMException&&error.name==='AbortError')){set({error:String(error)});await get().stop();}throw error;}
    finally{
      signal.removeEventListener('abort',abort);
      try{await stopComputerTask(ownSession);}catch{if(controller===ownController)set({error:'Could not finish stopping computer jobs. Press Ctrl+Alt+Pause.'});}
      if(controller===ownController){set({busy:false,...(get().session===ownSession?{session:null,taskId:null}:{})});controller=null;}
    }
  },
}));

async function acceptResult(result:ComputerResult,signal?:AbortSignal):Promise<ComputerResult>{
  signal?.throwIfAborted();
  const store=useComputerStore.getState();
  useComputerStore.setState({phase:result.summary,recent:[...store.recent.slice(-19),result]});
  if(result.status!=='awaiting_confirmation')return result;
  return new Promise(resolve=>{
    const finish=(reply:ComputerResult)=>{signal?.removeEventListener('abort',stop);resolve(reply);};
    const stop=()=>{void useComputerStore.getState().stop();};
    signal?.addEventListener('abort',stop,{once:true});
    useComputerStore.setState({panelOpen:true,pending:{result,resolve:finish},phase:'Waiting for your confirmation'});
  });
}
