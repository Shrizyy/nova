import { describe, it, expect, vi } from 'vitest';
import { runComputerLoop } from './computer-loop';

describe('computer task loop', () => {
  it('executes a tool and verifies before reporting success', async () => {
    const complete = vi.fn()
      .mockResolvedValueOnce({content:'', tool_calls:[{id:'one',function:{name:'computer_control',arguments:'{"operation":"list","params":{"path":"downloads"}}'}}]})
      .mockResolvedValueOnce({content:'Verified the file list.'});
    const execute = vi.fn().mockResolvedValue({status:'success',summary:'Listed files.',data:{entries:[]},action_id:'action'});
    const result = await runComputerLoop({messages:[{role:'user',content:'List Downloads'}],complete,execute,signal:new AbortController().signal});
    expect(execute).toHaveBeenCalledTimes(1);
    expect(complete).toHaveBeenCalledTimes(2);
    expect(result).toBe('Verified the file list.');
  });

  it('never lets a model approve its own action', async () => {
    const complete = vi.fn().mockResolvedValue({tool_calls:[{id:'bad',function:{name:'approve',arguments:'{}'}}]});
    const execute = vi.fn();
    await expect(runComputerLoop({messages:[],complete,execute,signal:new AbortController().signal})).rejects.toThrow('unsupported tool');
    expect(execute).not.toHaveBeenCalled();
  });

  it('does not resume a model after a running tool is stopped', async () => {
    const controller = new AbortController();
    const complete = vi.fn().mockResolvedValue({tool_calls:[{id:'one',function:{name:'computer_control',arguments:'{"operation":"list","params":{}}'}}]});
    const execute = vi.fn().mockImplementation(async () => { controller.abort(); return {status:'cancelled',summary:'Stopped.',data:{}}; });
    await expect(runComputerLoop({messages:[],complete,execute,signal:controller.signal})).rejects.toThrow();
    expect(complete).toHaveBeenCalledTimes(1);
  });
});

it('pauses when closing an app requires a save decision',async()=>{
  const signal=new AbortController().signal;
  const complete=vi.fn().mockResolvedValue({tool_calls:[{id:'close',function:{name:'computer_control',arguments:JSON.stringify({operation:'close',params:{window_id:1}})}}]});
  const execute=vi.fn().mockResolvedValue({action_id:'x',status:'partial',summary:'Choose whether to save.',data:{manual_interaction_required:true}});
  expect(await runComputerLoop({messages:[],complete,execute,signal})).toBe('Choose whether to save.');
  expect(complete).toHaveBeenCalledTimes(1);
});
