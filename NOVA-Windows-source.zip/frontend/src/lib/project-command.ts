/** Parse a single command into arguments without evaluating shell operators. */
export function parseProjectCommand(text: string): string[] {
  const args: string[] = [];
  let value = '', quote = '', started = false;
  for (let i=0; i<text.length; i++) {
    const char = text[i];
    if (quote) {
      if (char === quote) quote = '';
      else if (quote === '"' && char === '\\' && (text[i+1] === '"' || text[i+1] === '\\')) value += text[++i];
      else value += char;
    } else if (char === '"' || char === "'") { quote = char; started = true; }
    else if (/\s/.test(char)) { if (started) { args.push(value); value=''; started=false; } }
    else { if (/[|;&<>]/.test(char)) throw new Error('Run one command at a time.'); value += char; started=true; }
  }
  if (quote) throw new Error('Close the quote in your command.');
  if (started) args.push(value);
  if (!args.length) throw new Error('Enter a project command.');
  return args;
}
