import { describe, expect, it } from 'vitest';
import { parseProjectCommand } from './project-command';
describe('project commands', () => {
  it('parses normal build commands', () => expect(parseProjectCommand('npm run build')).toEqual(['npm','run','build']));
  it('preserves code inside quoted arguments', () => expect(parseProjectCommand('python -c "print(\'hello world\')"')).toEqual(['python','-c',"print('hello world')"]));
  it('rejects shell operators', () => expect(() => parseProjectCommand('npm test && npm run build')).toThrow());
  it('rejects unclosed quotes', () => expect(() => parseProjectCommand('node "unfinished')).toThrow());
});
