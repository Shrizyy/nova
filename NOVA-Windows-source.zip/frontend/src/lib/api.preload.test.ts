import { afterEach, expect, test, vi } from 'vitest';
import { preloadModel } from './api';
afterEach(() => vi.unstubAllGlobals());
test('gateway models never preload through the local Ollama endpoint', async () => {
  const fetch = vi.fn().mockRejectedValue(new Error('Gateway routed to Ollama'));
  vi.stubGlobal('fetch', fetch);
  await preloadModel('omniroute/codex/gpt-5.6-luna-low', 'omniroute');
  expect(fetch).not.toHaveBeenCalled();
});
test('local models retain Ollama preloading', async () => {
  const fetch = vi.fn().mockResolvedValue({ ok: true });
  vi.stubGlobal('fetch', fetch);
  await preloadModel('qwen3.5:4b', 'ollama');
  expect(fetch).toHaveBeenCalledWith('http://127.0.0.1:11434/api/generate', expect.objectContaining({ method: 'POST' }));
});
