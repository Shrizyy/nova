/** Route explicit laptop commands to the loopback-only action service.
 * The public ngrok URL for chat/webhooks never receives these requests.
 */
const ACTION_PATTERN = /^(?:(?:please|can you|could you|i want you to)\s+)?(?:organize|sort|tidy(?: up)?|open|launch|start|run|find (?:installed )?(?:apps|games)|search for (?:installed )?(?:apps|games)|(?:list|show) (?:installed )?(?:apps|games)|move|(?:create|make) (?:a )?(?:new )?folder|(?:list|show) (?:the )?files in|undo (?:the )?last|confirm|cancel)\b/i;
const WAKE_PREFIX = /^hey[\s,]+(?:nova|jarvis)\b[\s,!.?]*/i;

function withoutWakePhrase(text: string): string {
  return text.trim().replace(WAKE_PREFIX, '').trim();
}

export function localActionCommand(input: string, previousUserMessages: string[]): string | null {
  if (!['127.0.0.1', 'localhost'].includes(window.location.hostname)) return null;
  const command = withoutWakePhrase(input);
  if (/^(?:empty|clear) (?:my |the )?recycle bin\b|^(?:delete|remove) (?:everything|all(?: the)?(?: files)?) (?:in|from) (?:my |the )?recycle bin\b/i.test(command)) return command;
  if (ACTION_PATTERN.test(command)) return command;
  if (/^(?:you do it|do it yourself|please do it)[.!?]*$/i.test(command)) {
    for (const prior of [...previousUserMessages].reverse().slice(0, 4)) {
      const folder = prior.match(/\b(downloads|documents|desktop|pictures)\b/i)?.[1];
      if (folder && /\b(organize|sort|tidy|clean)\b/i.test(prior)) {
        return `organize my ${folder}`;
      }
      const previousCommand = withoutWakePhrase(prior);
      if (ACTION_PATTERN.test(previousCommand)) return previousCommand;
    }
  }
  return null;
}

export async function runLocalAction(command: string, taskId='local-actions', signal?:AbortSignal): Promise<string> {
  const {useComputerStore}=await import('./computer-store');
  try {return (await useComputerStore.getState().legacy(command,taskId,signal)).summary;}
  catch(error){return `Computer action could not run: ${String(error)}`;}
}

