import {afterEach,beforeEach,describe,expect,it,vi} from 'vitest';
vi.mock('./computer-client',()=>({pairComputer:vi.fn(),computerCall:vi.fn(),executeComputerAction:vi.fn(),approveComputerAction:vi.fn(),stopComputerTask:vi.fn().mockResolvedValue(undefined)}));
import {pairComputer,stopComputerTask} from './computer-client';
import {useComputerStore} from './computer-store';
beforeEach(()=>useComputerStore.setState({enabled:false,panelOpen:false,busy:false,session:null,pending:null,recent:[],error:''}));
afterEach(()=>vi.clearAllMocks());
describe('computer ownership',()=>{
  it('cancels a pairing that completes after Stop',async()=>{
    let resolve:any;vi.mocked(pairComputer).mockImplementation(()=>new Promise(r=>{resolve=r;}));
    const pending=useComputerStore.getState().ensureSession('old-task');
    await useComputerStore.getState().stop();
    const session={session_id:'s',task_id:'old-task',token:'fixture',channel:'chat' as const};resolve(session);
    await expect(pending).rejects.toMatchObject({name:'AbortError'});
    expect(useComputerStore.getState().session).toBeNull();
    expect(stopComputerTask).toHaveBeenCalledWith(session);
  });
});
