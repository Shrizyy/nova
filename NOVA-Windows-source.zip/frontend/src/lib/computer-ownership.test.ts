import {describe,it,expect} from 'vitest';
import {shouldStopComputerTransition} from './computer-ownership';
const previous={conversationId:null,model:'model',path:'/'};
describe('conversation task ownership',()=>{
 it('allows a newly created first chat to own the task already pairing for it',()=>{
  expect(shouldStopComputerTransition(previous,{...previous,conversationId:'new-chat'},{taskId:'new-chat',busy:true})).toBe(false);
 });
 it('stops an old conversation task when switching to another',()=>{
  expect(shouldStopComputerTransition({...previous,conversationId:'old-chat'},{...previous,conversationId:'new-chat'},{taskId:'old-chat',busy:true})).toBe(true);
 });
 it('stops a task on model or page changes',()=>{
  expect(shouldStopComputerTransition(previous,{...previous,model:'other'},{taskId:'task',busy:true})).toBe(true);
  expect(shouldStopComputerTransition(previous,{...previous,path:'/coding'},{taskId:'task',busy:true})).toBe(true);
 });
});
