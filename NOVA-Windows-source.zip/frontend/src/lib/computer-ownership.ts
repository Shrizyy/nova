type View={conversationId:string|null;model:string;path:string};
export function shouldStopComputerTransition(previous:View,next:View,computer:{taskId:string|null;busy:boolean}):boolean {
  return computer.busy && (previous.model!==next.model || previous.path!==next.path || (previous.conversationId!==next.conversationId && computer.taskId!==next.conversationId));
}
